const express = require('express')
const server = express()
const mongoose = require('mongoose')
const Barcode = require("./models/barcode.model")
const port = 1000

//middleware to parse json bodies
//this is obligatory to accessjson body
server.use(express.json());


//handle get all barcodes
server.get('/api/barcodes', async (req,res) => {
    try{
        var barcodes = await Barcode.find();
        res.status(200).json(barcodes)
        console.log('get request sent server ')
    }catch(error){
        res.status(500).json({error : error.message})
    }
})

//handle get one barcode
server.get('/api/barcodes/:id' , async (req, res) => {
    try{
        const barcode = await Barcode.findById(req.params.id);
        if(barcode)
            res.status(200).json(barcode)
        else
            res.status(404).json({error:`Barcode not found with id : ${req.params.id}`})
    }catch(error){
        res.status(500).json({error : error.message})
    }
})

// handle add barcode
server.post('/api/barcodes', async (req,res) => {
    try{
        const barcode = await Barcode.create(req.body)
        res.status(200).json(barcode);
    }catch(error){
        console.log(`Error : ${error}`)
    }
})

//handle update barcode
server.put('/api/barcodes/:id', async (req,res) => {
    try{
        const barcode = await Barcode.findByIdAndUpdate(req.params.id,req.body, { new: true, runValidators: true });
        if(barcode)
            res.status(200).json(barcode);
        else
            res.status(404).json({ error : 'Barcode not found'});
    }catch(error){
        console.log(`Error: ${error}`);
        res.status(400).json({error : error.message});
    }
});

//handle delete barcode
server.delete('/api/barcodes/:id', async (req,res) => {
    try{
        const barcode = await Barcode.findByIdAndDelete(req.params.id);
        if (barcode)
            res.status(200).json({ message : 'Barcode Deleted Successfully'});
        else
            res.status(404).json({ error : 'Barcode not found'});

    }catch(error){
        console.log(`Error: ${error}`);
        res.status(400).json({error : error.message});
    }
});
//connect to database
mongoose.connect("mongodb+srv://zedaykayo:2WyJE2DLI60YMBM9@cluster0.q05j5kj.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
.then(() =>{
    console.log("Mongo Db Connected")
    
    server.listen(port,(error) =>{
        if(error)
            console.log(`Error : ${error}`)
        else
            console.log(`Server running on port : ${port}`)
    })

})
.catch(() =>{
    console.log("Mongo Db Connection Failed")
})

