const mongoose = require("mongoose");
const BarcodeSchema = mongoose.Schema(
  {
    title: {
      type: String,
      required: [true ,'Title Required'],
    },
    description: {
      type: String,
      required: false,
    },
    image: {
      type: String,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);
const Barcode = mongoose.model("Barcode",BarcodeSchema);
module.exports =  Barcode;